package spaceStation.models.astronauts;

public class Meteorologist extends BaseAstronaut {
    private static final double OXYGEN = 90.0;

    protected Meteorologist(String name) {
        super(name, OXYGEN);
    }

}
